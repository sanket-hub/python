def ChkEven(iNo):
	if(iNo%2==0):
		print("Even number")
	else:
		print("Odd number")
		
print("Enter 1st number");
x=input();

ChkEven(x);
