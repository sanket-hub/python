from Arithmatic import  *

print("Enter 1st number");
x=input();

print("Enter 2nd number");
y=input();

ret=Add(x,y);
print(ret);

ret=Sub(x,y);
print(ret);

ret=Mult(x,y);
print(ret);

ret=Div(x,y);
print(ret);

