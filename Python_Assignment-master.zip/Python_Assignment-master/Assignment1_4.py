def Display(No):
	for i in range (0,No):
		print("Marvellous");
		
Display(5);
	
