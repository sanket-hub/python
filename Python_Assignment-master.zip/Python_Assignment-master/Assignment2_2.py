def Pattern(no):
	for i in range (0,no,1):
		for j in range (0,no,1):
			print("* "),
		print("\n");
		
print("Enter number");
no=input();

Pattern(no);
