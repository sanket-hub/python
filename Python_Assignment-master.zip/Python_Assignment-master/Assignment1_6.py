def ChkNum(iNo):
	if(iNo<0):
		print("Negative number")
	elif(iNo>0):
		print("Positive number")
	else:
		print(0);
			
print("Enter number");
x=input();

ChkNum(x);
