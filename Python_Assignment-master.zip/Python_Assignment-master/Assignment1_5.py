def Display(No):
	for i in range(No,0,-1):
		print(i);
		
Display(10);
