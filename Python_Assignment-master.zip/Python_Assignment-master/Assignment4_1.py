def Main():
	
	no=int(input('Enter number  '));
	
	ret=lambda no: no**2;
	
	print(ret(no));

if(__name__=="__main__"):
	Main();
