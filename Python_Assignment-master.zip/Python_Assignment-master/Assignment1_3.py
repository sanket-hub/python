def Addition(no1, no2):
	ans=0;
	ans=no1+no2;
	
	return ans;
	

print("Enter 1st number");
no1=input();

print("Enter 2nd number");
no2=input();

ret=Addition(no1,no2);

print(ret);
