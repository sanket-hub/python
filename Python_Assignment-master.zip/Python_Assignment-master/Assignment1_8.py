def Display(No):
	for i in range (0,No):
		print("*");
		
print("Enter number");
no=input();

Display(no);
	
